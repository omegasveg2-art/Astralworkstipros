// Oxide: Survival Island (obfuscated build: re-dump + update after every game patch). Offsets from the "parachute-patch"
// dump (PlayerManager grew a new parachuteConfig field at 0x68, shifting fpManager/vitals). Exact version string not
// embedded in the dump; matched by field diff against the previous dump, same way the earlier build was identified.
#pragma once
#include <cstdint>

struct ClassRef { const char* ns; const char* name; uint64_t typeinfo_rva; };

namespace off {
namespace PlayerManager {            // class Oxide.PlayerManager : NetworkBehaviour
  constexpr ClassRef cls = {"Oxide", "PlayerManager", 0};
  constexpr uint32_t netIdentity = 0x40;          // NetworkBehaviour.<netIdentity>k__BackingField
  constexpr uint32_t fpManager = 0xD0;            // was 0x90 -- shifted by the new parachuteConfig field at the front of the class (this patch's dump)
  constexpr uint32_t vitals = 0x108;              // was 0xC8, same shift
  constexpr uint32_t s_clientPlayerList = 0x10;   // static List<PlayerManager>
  constexpr uint32_t s_activePlayerList = 0x8;
}
namespace NetworkIdentity { constexpr uint32_t isLocalPlayer = 0x4A; }
namespace FPManager { constexpr ClassRef cls = {"Oxide", "FPManager", 0}; constexpr uint32_t m_WorldCamera = 0x20; }
namespace FPHitscan {
  constexpr ClassRef cls = {"Oxide", "FPHitscan", 0};   // confirmed by in-game scan (find_name_any_ns): ns='Oxide'
  // Latest dump (parachute-patch build): only ONE private void X(Ray x) in this class now -- "emP". No more
  // guessing between two candidates like the previous build (AwB/rvq, both since obsolete -- that dump is stale).
  constexpr const char* fireMethod = "emP";
}
namespace Vitals {                   // GenericVitals/kAg: Entity (kAH) at 0x68; kAH.Health (reactive float) 0x98, DisplayName 0x88
  constexpr uint32_t Entity = 0x68;
  constexpr uint32_t m_MaxHealth = 0x88;
  constexpr uint32_t E_DisplayName = 0x88;
  constexpr uint32_t E_Health = 0x98;
  constexpr uint32_t E_Velocity = 0xB0;
}
}
